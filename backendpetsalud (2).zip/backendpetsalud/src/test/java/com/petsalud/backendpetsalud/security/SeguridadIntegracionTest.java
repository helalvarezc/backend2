package com.petsalud.backendpetsalud.security;

import com.jayway.jsonpath.JsonPath;
import com.petsalud.backendpetsalud.entity.Rol;
import com.petsalud.backendpetsalud.entity.Usuario;
import com.petsalud.backendpetsalud.repository.UsuarioRepository;
import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SeguridadIntegracionTest {

    private static final String CLAVE = "Clave1234";

    @Autowired
    private MockMvc mvc;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${app.jwt.secret}")
    private String secreto;

    @Value("${app.jwt.issuer}")
    private String emisor;

    private Long idCliente;
    private Long idOtroCliente;

    @BeforeEach
    void preparar() {
        usuarioRepository.deleteAll();
        crear("admin@petsalud.cl", Rol.ADMIN);
        crear("vet@petsalud.cl", Rol.VETERINARIO);
        idCliente = crear("cliente@petsalud.cl", Rol.CLIENTE).getId();
        idOtroCliente = crear("otro@petsalud.cl", Rol.CLIENTE).getId();
    }

    private Usuario crear(String email, Rol rol) {
        return usuarioRepository.save(Usuario.builder()
                .email(email)
                .password(passwordEncoder.encode(CLAVE))
                .nombre("Nombre")
                .apellido("Apellido")
                .rol(rol)
                .build());
    }

    private String token(String email) throws Exception {
        MvcResult r = mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"password\":\"" + CLAVE + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonPath.read(r.getResponse().getContentAsString(), "$.token");
    }

    private String bearer(String email) throws Exception {
        return "Bearer " + token(email);
    }

    @Test
    @DisplayName("Login correcto entrega un JWT firmado con tres partes")
    void loginCorrecto() throws Exception {
        String t = token("cliente@petsalud.cl");
        assertTrue(t.split("\\.").length == 3);
    }

    @Test
    @DisplayName("Login con contraseña incorrecta responde 401")
    void loginIncorrecto() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"cliente@petsalud.cl\",\"password\":\"Incorrecta1\"}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("SQL Injection en el campo contraseña no autentica")
    void sqlInjectionPassword() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"cliente@petsalud.cl\",\"password\":\"' OR '1'='1\"}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("SQL Injection en el campo email es rechazado por validación")
    void sqlInjectionEmail() throws Exception {
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"admin' OR '1'='1' --\",\"password\":\"x\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("SQL Injection en parámetro de consulta se trata como dato literal")
    void sqlInjectionParametro() throws Exception {
        mvc.perform(get("/api/productos/categoria")
                        .param("categoria", "' OR '1'='1")
                        .header("Authorization", bearer("admin@petsalud.cl")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    @Test
    @DisplayName("Sin token se responde 401")
    void sinToken() throws Exception {
        mvc.perform(get("/api/productos")).andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("HTTP Basic ya no es aceptado")
    void basicRechazado() throws Exception {
        mvc.perform(get("/api/productos")
                        .header("Authorization", "Basic YWRtaW5AcGV0c2FsdWQuY2w6Q2xhdmUxMjM0"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Token con firma alterada se rechaza")
    void tokenAlterado() throws Exception {
        String t = token("admin@petsalud.cl");
        int inicioFirma = t.lastIndexOf('.') + 1;
        char original = t.charAt(inicioFirma);
        char cambio = original == 'A' ? 'B' : 'A';
        String alterado = t.substring(0, inicioFirma) + cambio + t.substring(inicioFirma + 1);
        mvc.perform(get("/api/usuarios").header("Authorization", "Bearer " + alterado))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Token expirado se rechaza")
    void tokenExpirado() throws Exception {
        JwtService expirado = new JwtService(secreto, -1000L, emisor);
        String t = expirado.generarToken(new UsuarioDetails(
                usuarioRepository.findByEmail("admin@petsalud.cl").orElseThrow()));
        mvc.perform(get("/api/usuarios").header("Authorization", "Bearer " + t))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Token firmado con otra clave se rechaza")
    void tokenOtraClave() throws Exception {
        String otra = java.util.Base64.getEncoder()
                .encodeToString("otra-clave-distinta-de-al-menos-32-bytes!!".getBytes());
        JwtService falso = new JwtService(otra, 3600000L, emisor);
        String t = falso.generarToken(new UsuarioDetails(
                usuarioRepository.findByEmail("admin@petsalud.cl").orElseThrow()));
        mvc.perform(get("/api/usuarios").header("Authorization", "Bearer " + t))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Token con algoritmo none se rechaza")
    void tokenAlgNone() throws Exception {
        String t = "eyJhbGciOiJub25lIn0.eyJzdWIiOiJhZG1pbkBwZXRzYWx1ZC5jbCIsImlzcyI6InBldHNhbHVkLWJhY2tlbmQifQ.";
        mvc.perform(get("/api/usuarios").header("Authorization", "Bearer " + t))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("CLIENTE no puede listar usuarios (403) y ADMIN sí (200)")
    void rolesListarUsuarios() throws Exception {
        mvc.perform(get("/api/usuarios").header("Authorization", bearer("cliente@petsalud.cl")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/usuarios").header("Authorization", bearer("vet@petsalud.cl")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/usuarios").header("Authorization", bearer("admin@petsalud.cl")))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("Solo ADMIN crea productos")
    void rolesCrearProducto() throws Exception {
        String cuerpo = "{\"nombre\":\"Alimento\",\"categoria\":\"Comida\",\"precio\":1000,\"stock\":5}";
        mvc.perform(post("/api/productos").contentType(MediaType.APPLICATION_JSON).content(cuerpo)
                        .header("Authorization", bearer("cliente@petsalud.cl")))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/productos").contentType(MediaType.APPLICATION_JSON).content(cuerpo)
                        .header("Authorization", bearer("vet@petsalud.cl")))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Solo ADMIN lista todas las ventas")
    void rolesVentas() throws Exception {
        mvc.perform(get("/api/ventas").header("Authorization", bearer("vet@petsalud.cl")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/ventas").header("Authorization", bearer("admin@petsalud.cl")))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("VETERINARIO accede a citas y CLIENTE no")
    void rolesCitas() throws Exception {
        mvc.perform(get("/api/citas/veterinario/1").header("Authorization", bearer("cliente@petsalud.cl")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/citas/veterinario/1").header("Authorization", bearer("vet@petsalud.cl")))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("IDOR: un cliente no accede a los datos de otro cliente")
    void idor() throws Exception {
        String t = bearer("cliente@petsalud.cl");
        mvc.perform(get("/api/usuarios/" + idOtroCliente).header("Authorization", t))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/usuarios/" + idCliente).header("Authorization", t))
                .andExpect(status().isOk());
        mvc.perform(get("/api/ventas/usuario/" + idOtroCliente).header("Authorization", t))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/mascotas/propietario/" + idOtroCliente).header("Authorization", t))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("La contraseña y su hash nunca salen en las respuestas")
    void passwordOculta() throws Exception {
        MvcResult r = mvc.perform(get("/api/usuarios/me").header("Authorization", bearer("cliente@petsalud.cl")))
                .andExpect(status().isOk())
                .andReturn();
        String cuerpo = r.getResponse().getContentAsString();
        assertFalse(cuerpo.contains("password"));
        assertFalse(cuerpo.contains("$2a$"));
    }

    @Test
    @DisplayName("El registro público siempre crea rol CLIENTE aunque se envíe ADMIN")
    void registroIgnoraRol() throws Exception {
        mvc.perform(post("/api/auth/registro")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"nuevo@petsalud.cl\",\"password\":\"Segura123\",\"nombre\":\"Ana\","
                                + "\"apellido\":\"Perez\",\"rol\":\"ADMIN\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rol").value("CLIENTE"));
        Usuario u = usuarioRepository.findByEmail("nuevo@petsalud.cl").orElseThrow();
        assertTrue(u.getPassword().startsWith("$2"));
    }

    @Test
    @DisplayName("Registro con contraseña débil es rechazado")
    void registroPasswordDebil() throws Exception {
        mvc.perform(post("/api/auth/registro")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"debil@petsalud.cl\",\"password\":\"abc\",\"nombre\":\"Ana\","
                                + "\"apellido\":\"Perez\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("XSS: el HTML ingresado se almacena escapado")
    void xssEscapado() throws Exception {
        MvcResult r = mvc.perform(post("/api/auth/registro")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"xss@petsalud.cl\",\"password\":\"Segura123\","
                                + "\"nombre\":\"<script>alert(1)</script>\",\"apellido\":\"<img src=x onerror=alert(1)>\"}"))
                .andExpect(status().isCreated())
                .andReturn();
        String t = JsonPath.read(r.getResponse().getContentAsString(), "$.token");
        MvcResult me = mvc.perform(get("/api/usuarios/me").header("Authorization", "Bearer " + t))
                .andExpect(status().isOk())
                .andReturn();
        String cuerpo = me.getResponse().getContentAsString();
        assertFalse(cuerpo.contains("<script>"));
        assertFalse(cuerpo.contains("<img"));
        assertTrue(cuerpo.contains("&lt;script&gt;"));
    }

    @Test
    @DisplayName("CSRF: sin cookies de sesión no se crea sesión ni se acepta la petición")
    void csrfSinSesion() throws Exception {
        MvcResult r = mvc.perform(post("/api/auth/login")
                        .cookie(new Cookie("JSESSIONID", "forjada"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"cliente@petsalud.cl\",\"password\":\"" + CLAVE + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        assertNull(r.getRequest().getSession(false));
        mvc.perform(post("/api/mascotas/propietario/" + idCliente)
                        .cookie(new Cookie("JSESSIONID", "forjada"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nombre\":\"Firulais\"}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Cabeceras de seguridad presentes")
    void cabeceras() throws Exception {
        mvc.perform(get("/api/productos").header("Authorization", bearer("admin@petsalud.cl")))
                .andExpect(header().string("X-Content-Type-Options", "nosniff"))
                .andExpect(header().string("X-Frame-Options", "DENY"))
                .andExpect(header().string("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'"))
                .andExpect(header().string("Referrer-Policy", "no-referrer"))
                .andExpect(header().string("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate"));
    }

    @Test
    @DisplayName("Rutas no definidas quedan denegadas")
    void rutaDesconocida() throws Exception {
        mvc.perform(get("/api/admin/secreto").header("Authorization", bearer("admin@petsalud.cl")))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Derecho de supresión: el cliente elimina su propia cuenta")
    void eliminarCuentaPropia() throws Exception {
        String t = bearer("cliente@petsalud.cl");
        mvc.perform(delete("/api/usuarios/me").header("Authorization", t))
                .andExpect(status().isNoContent());
        assertTrue(usuarioRepository.findByEmail("cliente@petsalud.cl").isEmpty());
        mvc.perform(get("/api/usuarios/me").header("Authorization", t))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("Intentos repetidos fallidos siguen respondiendo 401 y no revelan si el usuario existe")
    void intentosRepetidos() throws Exception {
        for (int i = 0; i < 6; i++) {
            mvc.perform(post("/api/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"email\":\"cliente@petsalud.cl\",\"password\":\"Mala" + i + "xyz\"}"))
                    .andExpect(status().isUnauthorized())
                    .andExpect(jsonPath("$.error").value("Credenciales inválidas"));
        }
        mvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"noexiste@petsalud.cl\",\"password\":\"Mala1234\"}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error").value("Credenciales inválidas"));
    }
}
