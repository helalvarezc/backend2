package com.petsalud.backendpetsalud.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

@Component
public class AuditoriaSeguridad {

    private static final Logger LOG = LoggerFactory.getLogger("AUDITORIA_SEGURIDAD");
    private static final int UMBRAL_INTENTOS = 5;
    private static final Duration VENTANA = Duration.ofMinutes(10);
    private static final int MAX_USUARIOS_REGISTRADOS = 10000;

    private final Map<String, Deque<Instant>> fallos = new ConcurrentHashMap<>();

    @EventListener
    public void loginFallido(AbstractAuthenticationFailureEvent evento) {
        String usuario = enmascarar(evento.getAuthentication().getName());
        LOG.warn("LOGIN_FALLIDO usuario={} motivo={}", usuario, evento.getException().getClass().getSimpleName());
        registrarFallo(usuario);
    }

    @EventListener
    public void loginExitoso(AuthenticationSuccessEvent evento) {
        String usuario = enmascarar(evento.getAuthentication().getName());
        fallos.remove(usuario);
        LOG.info("LOGIN_EXITOSO usuario={}", usuario);
    }

    public void noAutenticado(String metodo, String ruta) {
        LOG.warn("ACCESO_SIN_TOKEN_VALIDO metodo={} ruta={}", limpiar(metodo), limpiar(ruta));
    }

    public void accesoDenegado(String usuario, String metodo, String ruta) {
        LOG.warn("ACCESO_DENEGADO usuario={} metodo={} ruta={}", enmascarar(usuario), limpiar(metodo), limpiar(ruta));
    }

    public void tokenInvalido(String ruta) {
        LOG.warn("TOKEN_INVALIDO ruta={}", limpiar(ruta));
    }

    private void registrarFallo(String usuario) {
        if (fallos.size() > MAX_USUARIOS_REGISTRADOS) {
            fallos.clear();
        }
        Deque<Instant> intentos = fallos.computeIfAbsent(usuario, k -> new ConcurrentLinkedDeque<>());
        Instant ahora = Instant.now();
        intentos.addLast(ahora);
        while (!intentos.isEmpty() && intentos.peekFirst().isBefore(ahora.minus(VENTANA))) {
            intentos.pollFirst();
        }
        if (intentos.size() >= UMBRAL_INTENTOS) {
            LOG.error("ALERTA_FUERZA_BRUTA usuario={} intentos={} ventana_min={}",
                    usuario, intentos.size(), VENTANA.toMinutes());
        }
    }

    static String limpiar(String valor) {
        return valor == null ? "-" : valor.replaceAll("[\\r\\n\\t]", "_");
    }

    static String enmascarar(String email) {
        String limpio = limpiar(email);
        int arroba = limpio.indexOf('@');
        if (arroba <= 1) {
            return "***" + (arroba >= 0 ? limpio.substring(arroba) : "");
        }
        return limpio.charAt(0) + "***" + limpio.substring(arroba);
    }
}
