package com.petsalud.backendpetsalud.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.deser.std.StringDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;

@Configuration
public class JacksonSanitizerConfig {

    @Bean
    public SimpleModule sanitizerModule() {
        SimpleModule module = new SimpleModule("SanitizerModule");
        module.addDeserializer(String.class, new HtmlEscapingStringDeserializer());
        return module;
    }

    static class HtmlEscapingStringDeserializer extends StdDeserializer<String> {

        HtmlEscapingStringDeserializer() {
            super(String.class);
        }

        @Override
        public String deserialize(JsonParser parser, DeserializationContext ctxt) throws IOException {
            if (parser.currentToken() != JsonToken.VALUE_STRING) {
                return StringDeserializer.instance.deserialize(parser, ctxt);
            }
            String valor = parser.getText();
            if ("password".equals(parser.currentName())) {
                return valor;
            }
            return HtmlUtils.htmlEscape(valor, "UTF-8");
        }
    }
}
