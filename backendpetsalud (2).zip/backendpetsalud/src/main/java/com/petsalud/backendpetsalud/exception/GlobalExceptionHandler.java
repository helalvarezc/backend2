package com.petsalud.backendpetsalud.exception;

import com.petsalud.backendpetsalud.security.AuditoriaSeguridad;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.security.Principal;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private final AuditoriaSeguridad auditoria;

    public GlobalExceptionHandler(AuditoriaSeguridad auditoria) {
        this.auditoria = auditoria;
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<Map<String, Object>> autenticacion(AuthenticationException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("status", 401, "error", "Credenciales inválidas"));
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> accesoDenegado(AccessDeniedException ex, Principal principal, HttpServletRequest request) {
        auditoria.accesoDenegado(principal != null ? principal.getName() : null, request.getMethod(), request.getRequestURI());
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(Map.of("status", 403, "error", "Acceso denegado"));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> validacion(MethodArgumentNotValidException ex) {
        var campos = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField())
                .distinct()
                .toList();
        return ResponseEntity.badRequest()
                .body(Map.of("status", 400, "error", "Datos inválidos", "campos", campos));
    }

    @ExceptionHandler({IllegalArgumentException.class, HttpMessageNotReadableException.class})
    public ResponseEntity<Map<String, Object>> solicitudInvalida(Exception ex) {
        return ResponseEntity.badRequest()
                .body(Map.of("status", 400, "error", "Solicitud inválida"));
    }
}
