package com.petsalud.backendpetsalud.security;

import com.petsalud.backendpetsalud.entity.Usuario;
import com.petsalud.backendpetsalud.repository.MascotaRepository;
import com.petsalud.backendpetsalud.repository.NotificacionRepository;
import com.petsalud.backendpetsalud.repository.RecompensaRepository;
import com.petsalud.backendpetsalud.repository.UsuarioRepository;
import com.petsalud.backendpetsalud.repository.VentaRepository;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component("acceso")
public class AccesoSeguridad {

    private final UsuarioRepository usuarioRepository;
    private final MascotaRepository mascotaRepository;
    private final VentaRepository ventaRepository;
    private final NotificacionRepository notificacionRepository;
    private final RecompensaRepository recompensaRepository;

    public AccesoSeguridad(UsuarioRepository usuarioRepository,
                           MascotaRepository mascotaRepository,
                           VentaRepository ventaRepository,
                           NotificacionRepository notificacionRepository,
                           RecompensaRepository recompensaRepository) {
        this.usuarioRepository = usuarioRepository;
        this.mascotaRepository = mascotaRepository;
        this.ventaRepository = ventaRepository;
        this.notificacionRepository = notificacionRepository;
        this.recompensaRepository = recompensaRepository;
    }

    public boolean esUsuario(Long usuarioId, Authentication auth) {
        return usuarioId != null && usuarioRepository.findById(usuarioId)
                .map(u -> mismoEmail(u, auth)).orElse(false);
    }

    public boolean esMascota(Long mascotaId, Authentication auth) {
        return mascotaId != null && mascotaRepository.findById(mascotaId)
                .map(m -> mismoEmail(m.getPropietario(), auth)).orElse(false);
    }

    public boolean esVenta(Long ventaId, Authentication auth) {
        return ventaId != null && ventaRepository.findById(ventaId)
                .map(v -> mismoEmail(v.getUsuario(), auth)).orElse(false);
    }

    public boolean esNotificacion(Long notificacionId, Authentication auth) {
        return notificacionId != null && notificacionRepository.findById(notificacionId)
                .map(n -> mismoEmail(n.getUsuario(), auth)).orElse(false);
    }

    public boolean esRecompensa(Long recompensaId, Authentication auth) {
        return recompensaId != null && recompensaRepository.findById(recompensaId)
                .map(r -> mismoEmail(r.getUsuario(), auth)).orElse(false);
    }

    private boolean mismoEmail(Usuario usuario, Authentication auth) {
        return usuario != null && auth != null && usuario.getEmail().equals(auth.getName());
    }
}
