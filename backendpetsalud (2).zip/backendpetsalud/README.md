# Petsalud Backend

API REST para la gestión de una clínica veterinaria (usuarios, mascotas, citas, expedientes médicos, productos, ventas, notificaciones y recompensas), asegurada con Spring Security y JWT.

## Tecnologías

- Java 17 y Spring Boot 3.3.6
- Spring Security, Spring Data JPA y Bean Validation
- JWT con jjwt 0.12.6
- MySQL 8 (producción) y H2 (pruebas)

## Seguridad implementada

- Autenticación stateless con JWT (HS256, expiración de 1 hora, emisor verificado).
- Contraseñas con BCrypt (factor 12) y política de contraseña en el registro.
- Roles CLIENTE, VETERINARIO y ADMIN aplicados por ruta y método, más verificación de propiedad del recurso.
- Protección contra SQL Injection (consultas parametrizadas), XSS (escape de entrada y cabeceras CSP) y CSRF (API sin cookies de sesión).
- Cabeceras de seguridad, errores sin información interna y CORS con lista blanca.
- Monitoreo básico: registro de logins fallidos, accesos denegados y alerta de fuerza bruta (logger AUDITORIA_SEGURIDAD).
- Derechos del titular de datos: consulta (GET /api/usuarios/me), rectificación (PUT /api/usuarios/{id}) y supresión (DELETE /api/usuarios/me).

El análisis completo, la matriz de permisos y el plan de pruebas están en [docs/INFORME_TECNICO.docx](docs/INFORME_TECNICO.docx).

## Requisitos

- JDK 17
- Maven 3.9 o el wrapper incluido (mvnw)
- MySQL 8 con una base llamada petsalud_db

## Configuración

Las variables se leen desde el entorno (ver `.env.example`):

| Variable | Descripción | Valor por defecto |
|---|---|---|
| JWT_SECRET | Clave Base64 de al menos 32 bytes (obligatoria) | sin valor |
| JWT_EXPIRATION_MS | Vigencia del token en milisegundos | 3600000 |
| DB_URL | URL JDBC | jdbc:mysql://localhost:3306/petsalud_db |
| DB_USER | Usuario de la base | petsalud |
| DB_PASSWORD | Contraseña de la base | vacío |
| CORS_ALLOWED_ORIGINS | Orígenes permitidos, separados por coma | http://localhost:3000 |

Generar una clave: `openssl rand -base64 48`

## Ejecución

```bash
export JWT_SECRET=$(openssl rand -base64 48)
export DB_PASSWORD=su_clave
./mvnw spring-boot:run
```

## Pruebas

```bash
./mvnw test
```

La suite `SeguridadIntegracionTest` cubre login, JWT alterado, expirado y sin firma, roles por endpoint, IDOR, SQL Injection, XSS, CSRF y cabeceras de seguridad.

## Uso de la API

Registro (siempre crea un CLIENTE):

```bash
curl -X POST localhost:8080/api/auth/registro -H "Content-Type: application/json" \
  -d '{"email":"ana@mail.cl","password":"Segura123","nombre":"Ana","apellido":"Perez"}'
```

Login:

```bash
curl -X POST localhost:8080/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"ana@mail.cl","password":"Segura123"}'
```

Consumo de un endpoint protegido:

```bash
curl localhost:8080/api/usuarios/me -H "Authorization: Bearer <token>"
```

El primer usuario ADMIN debe insertarse directamente en la base con la contraseña cifrada con BCrypt. Desde ahí, el ADMIN crea otros usuarios con `POST /api/usuarios`.

## Permisos por rol

| Recurso | CLIENTE | VETERINARIO | ADMIN |
|---|---|---|---|
| Usuarios (listar, crear, eliminar) | No | No | Sí |
| Usuarios (ver y editar) | Solo propio | Solo propio | Sí |
| Productos (consultar) | Sí | Sí | Sí |
| Productos (crear, editar, eliminar) | No | No | Sí |
| Ventas | Solo propias | No | Sí |
| Mascotas (crear, editar, eliminar) | Solo propias | No | Sí |
| Mascotas (consultar) | Solo propias | Sí | Sí |
| Citas (agendar) | Solo su mascota | No | Sí |
| Citas (gestionar y consultar) | Solo su mascota | Sí | Sí |
| Expedientes médicos | Lectura de su mascota | Sí | Sí |
| Notificaciones | Solo propias | Sí | Sí |
| Recompensas | Solo propias (lectura) | No | Sí |

## Estructura

```
src/main/java/com/petsalud/backendpetsalud
  config/       sanitización de entrada
  controller/   endpoints REST
  dto/          objetos de entrada y salida
  entity/       entidades JPA
  exception/    manejo uniforme de errores
  repository/   acceso a datos
  security/     JWT, filtro, reglas de acceso
  service/      lógica de negocio
```
